<!-- Latest jQuery form server -->
<script src="https://code.jquery.com/jquery.min.js"></script>

<!-- Bootstrap JS form CDN -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>

<!-- jQuery sticky menu -->
<script src="<?php echo base_url('>assets/js/owl.carousel.min.js') ?>"></script>
<script src="<?php echo base_url('assets/js/jquery.sticky.js') ?>"></script>

<!-- jQuery easing -->
<script src="<?php echo base_url('assets/js/jquery.easing.1.3.min.js') ?>"></script>

<!-- Main Script -->
<script src="<?php echo base_url('assets/js/main.js') ?>"></script>
</body>
</html>